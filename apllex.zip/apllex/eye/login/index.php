<?php
@session_start();
include '../../core/configg.php';
if(isset($_POST['user']) && isset($_POST['pass'])) {
    $user = addslashes($_POST['user']);
    $pass = addslashes($_POST['pass']);
    if($user == $username && $pass == $password) {
        $_SESSION['user'] = "Administrator";
        $_SESSION['name'] = $username;
        print '<script>document.location.href="../";</script>';
    } else {
        $_SESSION['msg'] = '<div class="alert alert-danger"><span style="color:red;">Incorrect<span><br></div>';
    }
}
?>
<!doctype html>
<html class="img" style="background-image: url(images/bg.jpg?v0);height:100%!important" lang="en">
  <head>
  	<title>Signin</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body style="background: transparent;height: 100%;">
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">Login</h2>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-4">
					<div class="login-wrap p-0">
		      	<h3 class="mb-4 text-center">Have an account?</h3>
		      	<form action="" method="post" class="signin-form">
		      		<div class="form-group">
		      			<input type="text" name="user" class="form-control" placeholder="Username" required>
		      		</div>
	            <div class="form-group">
	              <input id="password-field" name="pass" type="password" class="form-control" placeholder="Password" required>
	              <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
	            </div>
	            <div class="form-group">
	            	<button type="submit" class="form-control btn btn-primary submit px-3">Sign In</button>
	            </div>
	        
	          </form>
			  <?php
			if(isset($_SESSION['msg'])) {
				echo $_SESSION['msg'];
				unset($_SESSION['msg']);
			}
			 ?>
	          
	      
		      </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

