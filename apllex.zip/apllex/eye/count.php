<?php

@session_start();
if(!isset($_SESSION['user'])) {
	header('Location: ./login');
    exit();
}

$folderPath = '../tracker'; // Replace with the actual folder path

$files = scandir($folderPath);
$fileCount = 0;

foreach ($files as $file) {
    if (is_file($folderPath . '/' . $file) && pathinfo($file, PATHINFO_EXTENSION) === 'json') {
        $fileCount++;
    }
}

echo $fileCount;

?>