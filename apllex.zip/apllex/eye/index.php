<?php
@session_start();
if(!isset($_SESSION['user'])) {
	header('Location: ./login');
} else {
	if(!isset($_GET['app'])) {
		include('Admin.php');
	} else {
		if($_GET['app'] === "logout") {
			@session_destroy();
			print '<script>document.location.href="./";</script>';
		}
	}
}
?>