<?php
@session_start();
if(!isset($_SESSION['user'])) {
	header('Location: ./login');
    exit();
}
 // Default value

//$fileName = $_POST['fileName'];
// Use the $fileName variable as needed in your PHP code
 
//echo $fileName 


// Get the JSON data from the request
$data = file_get_contents('php://input');
$requestBody = json_decode($data, true);


if (isset($requestBody['command']) && $requestBody['command'] === 'Del') {
    $fileName = $requestBody['fileName'];
    // Use the $fileName variable for further processing
    $name = '../tracker/'.$fileName.'.json';
    unlink($name);
} else if (isset($requestBody['fileName'])) {
    $fileName = $requestBody['fileName'];
    // Use the $fileName variable for further processing
    $name = '../tracker/'.$fileName.'.json';
    echo $name; echo '<br>';

    file_put_contents($name, $data);
}



echo $data;

// Update the JSON file with the received data
?>
