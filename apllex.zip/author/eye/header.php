
<?php
// Open the file
$file = fopen("../db.txt", 'r');

// Check if file is opened successfully
if ($file) {
    // Read the file line by line
    while (($line = fgets($file)) !== false) {
        // Check if the line contains AUTO_PILOT
        if (strpos($line, 'AUTO_PILOT') !== false) {
            // Extract the value after the '=' sign
            $value = explode('=', $line)[1];
            
            // Trim any leading/trailing whitespace
            $value = trim($value);
            
            // Output the value
            // echo "AUTO_PILOT value: $value";
            $pilotval = $value;
            
            // No need to continue looping, exit the loop
            break;
        }
    }
    
    // Close the file
    fclose($file);
} else {
    // Error opening the file
    echo "Error opening file: $file_path";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title> Admin eye</title>
    <link href="css/data-table-style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />

</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <!--a class="navbar-brand ps-3" href="./">
            <div title="Stripe" class="SVGInline SVGInline--cleaned SVG Logo Icon-color Icon-color--gray800 Box-root Flex-flex"><svg class="SVGInline-svg SVGInline--cleaned-svg SVG-svg Logo-svg Icon-color-svg Icon-color--gray800-svg" height="24" width="58" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 150"><path fill="#fff" fill-rule="evenodd" d="M360 77.4c0 2.4-.2 7.6-.2 8.9h-48.9c1.1 11.8 9.7 15.2 19.4 15.2 9.9 0 17.7-2.1 24.5-5.5v20c-6.8 3.8-15.8 6.5-27.7 6.5-24.4 0-41.4-15.2-41.4-45.3 0-25.4 14.4-45.6 38.2-45.6 23.7 0 36.1 20.2 36.1 45.8zm-49.4-9.5h25.8c0-11.3-6.5-16-12.6-16-6.3 0-13.2 4.7-13.2 16zm-63.5-36.3c17.5 0 34 15.8 34.1 44.8 0 31.7-16.3 46.1-34.2 46.1-8.8 0-14.1-3.7-17.7-6.3l-.1 28.3-25 5.3V33.2h22l1.3 6.2c3.5-3.2 9.8-7.8 19.6-7.8zm-6 68.9c9.2 0 15.4-10 15.4-23.4 0-13.1-6.3-23.3-15.4-23.3-5.7 0-9.3 2-11.9 4.9l.1 37.1c2.4 2.6 5.9 4.7 11.8 4.7zm-71.3-74.8V5.3L194.9 0v20.3l-25.1 5.4zm0 7.6h25.1v87.5h-25.1V33.3zm-26.9 7.4c5.9-10.8 17.6-8.6 20.8-7.4v23c-3.1-1.1-13.1-2.5-19 5.2v59.3h-25V33.3h21.6l1.6 7.4zm-50-29.1l-.1 21.7h19v21.3h-19v35.5c0 14.8 15.8 10.2 19 8.9v20.3c-3.3 1.8-9.3 3.3-17.5 3.3-14.8 0-25.9-10.9-25.9-25.7l.1-80.1 24.4-5.2zM25.3 58.7c0 11.2 38.1 5.9 38.2 35.7 0 17.9-14.3 28.2-35.1 28.2-8.6 0-18-1.7-27.3-5.7V93.1c8.4 4.6 19 8 27.3 8 5.6 0 9.6-1.5 9.6-6.1 0-11.9-38-7.5-38-35.1 0-17.7 13.5-28.3 33.8-28.3 8.3 0 16.5 1.3 24.8 4.6v23.5c-7.6-4.1-17.2-6.4-24.8-6.4-5.3 0-8.5 1.5-8.5 5.4z"></path></svg></div>    
        </a-->
        <!-- Sidebar Toggle-->
        <!-- <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button> -->
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0" style="visibility:hidden">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-dark" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
            </div>
        </form>

        <select class="xselect" id="apilot_val" style="margin-right: 18px;margin-top: 10px;margin-left: 5px;width: 111px;border-left-color: #3f00dd;">
            <option disabled="" value="">AUTO PILOT</option>
            <option value="YES" <?php if($pilotval == "YES"){echo 'selected';} ?>>YES</option>
            <option value="NO" <?php if($pilotval == "NO"){echo 'selected';} ?>>NO</option>
        </select>

        <select class="xselect" id="mustPause" style="margin-right: 18px;margin-top: 10px;margin-left: 5px;width: 75px;">
            <option selected="" disabled="" value="">PAUSE</option>
            <option value="YES">YES</option>
            <option value="NO">NO</option>
        </select>

        <input style="width:64px;margin-right:10px;cursor:pointer;border-left-color:red" onclick="Clean()" value="Clean" type="button" readonly>
        <input style="width:64px;margin-right:10px;cursor:pointer;border-left-color:green" onclick="reloadx()" value="realod" type="button" readonly>
        <input style="width:64px;margin-right:10px;cursor:pointer;border-left-color:yellow" onclick="javascript: window.location.href='./?app=logout'" value="logout" type="button" readonly>

        </nav>
<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Core</div>
                    <a class="nav-link" href="./">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                    <div class="sb-sidenav-menu-heading">Session Management</div>
                    <a class="nav-link" href=".?app=logout">
                        <div class="sb-nav-link-icon"><i class="fas fa-power-off"></i></div>
                        Logout
                    </a>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logged in as:</div>
                <?php print $_SESSION['name']; ?>
            </div>
        </nav>
    </div>